import 'dart:math'; 


//MATH UTILITY LIBRARY
class MathUtils {
 
  static double squareRoot(double number) {
    return sqrt(number);
  }


  static int factorial(int number) {
    if (number < 0) {
      throw ArgumentError('Factorial is not defined for negative numbers');
    }

    int result = 1;
    for (int i = 2; i <= number; i++) {
      result *= i;
    }
    return result;
  }

  static num power(double base, double exponent) {
    // Use dart:math's pow function
    return pow(base, exponent);
  }
}


void main() {
  double number = 16.0;
  double sqrtResult = MathUtils.squareRoot(number);
  print('Square root of $number is $sqrtResult');

  int factorialNumber = 5;
  int factorialResult = MathUtils.factorial(factorialNumber);
  print('Factorial of $factorialNumber is $factorialResult');
  double base = 2.0;
  double exponent = 3.0;
  num powerResult = MathUtils.power(base, exponent);
  print('Power of $base^$exponent is $powerResult');
}

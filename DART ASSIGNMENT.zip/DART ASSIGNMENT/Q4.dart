//SHOPPING CART
class ShoppingCart {
  final Map<String, CartItem> cartItems = {};

  void addItem(String itemName, double price, int quantity) {
    if (cartItems.containsKey(itemName)) {
      cartItems[itemName]!.quantity += quantity;
    } else {
      cartItems[itemName] = CartItem(itemName, price, quantity);
    }
  }
  void removeItem(String itemName) {
    cartItems.remove(itemName);
  }

  double calculateTotalPrice() {
    double totalPrice = 0.0;
    for (CartItem item in cartItems.values) {
      totalPrice += item.price * item.quantity;
    }
    return totalPrice;
  }
  void applyDiscount() {
    for (CartItem item in cartItems.values) {
      if (item.quantity >= 10) {
        item.price *= 0.9;
      }
    }
  }
  void displayCart() {
    print('Shopping Cart:');
    for (CartItem item in cartItems.values) {
      print('${item.name} - \$${item.price} x ${item.quantity}');
    }
    double totalPrice = calculateTotalPrice();
    print('Total Price: \$${totalPrice.toStringAsFixed(2)}');
  }
}
class CartItem {
  final String name;
  double price;
  int quantity;

  CartItem(this.name, this.price, this.quantity);
}

void main() {
  ShoppingCart cart = ShoppingCart();

  cart.addItem('Apple', 0.5, 20); 
  cart.addItem('Banana', 0.2, 15); 
  cart.addItem('Orange', 0.75, 5); 
  cart.displayCart();


  cart.applyDiscount();

  print('\nAfter applying discounts:');
  cart.displayCart();

  cart.removeItem('Banana');

  print('\nAfter removing an item:');
  cart.displayCart();
}

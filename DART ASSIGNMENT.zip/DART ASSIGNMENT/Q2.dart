
abstract class MediaItem {
  final String title;
  final String creator;

  MediaItem(this.title, this.creator);

  void displayInfo() {
    print('Title: $title');
    print('Creator: $creator');
  }
}

abstract class Playable {
  void play();
}

mixin Logger {
  void debug(String message) {
    print('[DEBUG]: $message');
  }
  void info(String message) {
    print('[INFO]: $message');
  }
  void warning(String message) {
    print('[WARNING]: $message');
  }
  void error(String message) {
    print('[ERROR]: $message');
  }
}

class Song extends MediaItem with Logger implements Playable {
  final int duration; 
  Song(String title, String artist, this.duration) : super(title, artist);

  @override
  void play() {
    info('Playing song: $title by $creator for $duration seconds.');
  }
}

class Album extends MediaItem with Logger implements Playable {
  final List<Song> songs;

  Album(String title, String artist, this.songs) : super(title, artist);

  @override
  void play() {
    info('Playing album: $title by $creator.');

    for (var song in songs) {
      song.play();
    }
  }
}

class Playlist extends MediaItem with Logger implements Playable {
  final List<Playable> items; 

  Playlist(String title, String owner, this.items) : super(title, owner);

  @override
  void play() {
    info('Playing playlist: $title by $creator.');
    for (var item in items) {
      item.play();
    }
  }
}


void main() {
  Song song1 = Song('Song A', 'Artist A', 240);
  Song song2 = Song('Song B', 'Artist B', 180);
  
  Album album = Album('Album A', 'Artist A', [song1, song2]);
  
  Playlist playlist = Playlist('My Playlist', 'User', [song1, album]);
  
  song1.displayInfo();
  album.displayInfo();
  playlist.displayInfo();
  
  song1.play();
  album.play();
  playlist.play();
}

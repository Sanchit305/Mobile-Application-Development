
abstract class Character {
  final String name;
  int health;

  Character(this.name, this.health);

  void attack(Character target);

  // Display character information
  void displayInfo() {
    print('Name: $name');
    print('Health: $health');
  }
}

mixin Logger {
  void debug(String message) {
    print('[DEBUG]: $message');
  }

  void info(String message) {
    print('[INFO]: $message');
  }

  void warning(String message) {
    print('[WARNING]: $message');
  }

  void error(String message) {
    print('[ERROR]: $message');
  }
}


class Warrior extends Character with Logger {
  Warrior(String name, int health) : super(name, health);

  @override
  void attack(Character target) {
   
    debug('$name attacks ${target.name} with a sword!');
    target.health -= 10; 
    info('${target.name} now has ${target.health} health.');
  }
}

class Mage extends Character with Logger {
  Mage(String name, int health) : super(name, health);

  @override
  void attack(Character target) {
   
    debug('$name casts a fireball at ${target.name}!');
    target.health -= 12; // Example damage
    info('${target.name} now has ${target.health} health.');
  }
}


class Rogue extends Character with Logger {
  Rogue(String name, int health) : super(name, health);

  @override
  void attack(Character target) {
   
    debug('$name attacks ${target.name} with a dagger!');
    target.health -= 8; 
    info('${target.name} now has ${target.health} health.');
  }
}


void main() {

  Warrior warrior = Warrior('Thorin', 100);
  Mage mage = Mage('Gandalf', 80);
  Rogue rogue = Rogue('Legolas', 90);


  warrior.displayInfo();
  mage.displayInfo();
  rogue.displayInfo();

  
  warrior.attack(mage);
  mage.attack(warrior);
  rogue.attack(warrior);
}

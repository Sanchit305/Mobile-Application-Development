//USER AUTHENTICATION SYSTEM
class Authenticator {
  bool login(String username, String password) {
    if (username == 'testuser' && password == 'password123') {
      print('Login successful');
      return true;
    } else {
      print('Login failed: Invalid username or password');
      return false;
    }
  }
  bool multiFactorAuth(String username, String password, String otp) {
    if (login(username, password) && otp == '123456') {
      print('Multi-factor authentication successful');
      return true;
    } else {
      print('Multi-factor authentication failed');
      return false;
    }
  }
}

class AuthorizationManager {
  bool authorize(String username, String resource) {
    if (username == 'admin' && resource == 'dashboard') {
      print('Access granted to $resource for user $username');
      return true;
    } else {
      print('Access denied to $resource for user $username');
      return false;
    }
  }
}

class User with Authenticator, AuthorizationManager {
  final String username;
  final String password;

  User(this.username, this.password);

  void attemptLoginAndAuthorize(String resource) {
    if (login(username, password)) {
      authorize(username, resource);
    }
  }
}
void main() {
  User user = User('testuser', 'password123');
  user.attemptLoginAndAuthorize('dashboard');
  print('\nTesting multi-factor authentication:');
  user.multiFactorAuth('testuser', 'password123', '123456');
}
